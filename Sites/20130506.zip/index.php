<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>You See You Do:::www.UseeUdo.com</title>
<meta name="distribution" content="Thailand" />
<meta name="revisit-after" content="7 days" />

<meta name="keywords" content="UseeUdo" />
<meta name="description" content="UseeUdo" />

<meta name="copyright" content="&copy; 2013 http://www.UseeUdo.asia" />
<meta name="robots" content="index,follow" />
<link href="style/style.css" rel="stylesheet" type="text/css" />

<!--slide-->
	<link rel="stylesheet" type="text/css" href="slide/engine1/style1.css" media="screen" />
	<style type="text/css">a#vlb{display:none}</style>
	<script type="text/javascript" src="slide/engine1/jquery.js"></script>
<!--slide-->

</head>

<body>

				<?
                   	  include("admin/include/connect.php");
					  mysql_query("SET NAMES UTF8");
                ?>
			<div id="head">
                  <div class="headleft">
            			 	 <?
                                        include "include/head.inc.php";
                              ?>
                   </div><!--headleft-->
                    <div class="headright">
                    		<div id="main_menu">
                               <?
                                         $current_page=1;
                                        include "include/main-menu.inc.php";
                              ?>
                            </div><!--main_menu-->
                    </div><!--headright-->
            </div><!--head-->
            <div class="cleaner"></div>
            <div id="slides">
                    		 <!-- -----------------------------slider----------------------------------- -->
                              <?
                                        include "include/slide.inc.php";
                              ?>
                                <!-- -----------------------------------End slider------------------------------ -->
                    
                    	</div><!--slides-->
            <div class="cleaner"></div>
	<div id="wrapper">
            
            <div id="content">
            		<div class="content-left">
                        	<?
                                        include "include/left-menu.inc.php";
                              ?>
                           
                    </div><!--content-left-->
                    
                    <div class="content-right">
                    	<table width="92%">
                        	<tr>
                            	<td align="justify">
                                    <h3>ยินดีต้อนรับท่านสู่ Website ของ UseeUdo.com ค่ะ</h3>
                                    <p>
                                            <span class="space-bar"></span>มาดูกันนะคะว่า ในอุตสาหกรรมอาหารมีอะไรที่ใส่ไปในอาหาร (ความลับ) แล้วช่วยให้เราปรุงอาหารง่ายขึ้น ได้รสชาดอร่อยขึ้น  มีคุณสมบัติที่ดีขึ้น เช่น ตัดแบ่งได้ชิ้นสวย นุ่มลื่นลิ้น ขึ้นฟู ทานแล้วไม่ติดฟัน ทั้งยังช่วยถนอมอาหารและเพิ่มสุนทรียะในการรับประทานให้มากขึ้น อีกทั้งยังสามารถช่วยประหยัดส่วนผสมบางตัว ลดปริมาณแป้ง น้ำตาลหรือไขมันที่ใช้เป็นส่วนผสมลงได้ไม่น้อย ช่วยให้ผู้ที่กำลังควบคุมน้ำหนักได้มีอาหารอร่อยๆ มีคุณภาพทานได้มากเท่าที่อยาก!
            และสิ่งที่เราใช้ใส่ลงไปในอาหารเหล่านี้ นักวิชาการเรียกว่า วัตถุเจือปนอาหาร หรือ Food Additives นี่เอง ที่จะช่วยให้คุณ ได้อาหารจานสุขภาพสำหรับทุกคนในครอบครัว ที่ทำได้แสนจะง่าย ในครัวเล็กๆ ของเราที่บ้าน แล้วยังสามารถช่วยประหยัดต้นทุนในการทำอาหารและขนมเลิศรสหลากหลายประเภท ได้อีกจำนวนหนึ่งด้วย
            
                                    </p>
                                    <p>
                                            <span class="space-bar"></span>สำหรับวัตถุประสงค์ของเวป UseeUdo.com นั้น นอกจากจะเป็นการเปิดเผยศาสตร์ของวัตถุเจือปนอาหารที่เราเคยเรียนเคยรู้กันมานิดๆ หน่อยๆ ที่โรงเรียน (และเพื่อหารายได้พิเศษด้วยแล้ว) เวปของเรายังมีการเปิดพื้นที่ให้เพื่อนๆ ได้เข้ามาแลกเปลี่ยนความรู้ แบ่งปันสูตรอาหาร หรือขอคำปรึกษาเกี่ยวกับเคล็ดลับการทำอาหาร ให้ทุกๆ คนได้ใช้เป็นแหล่งข้อมูลในการศึกษาค้นคว้าหาเคล็ดลับดีๆ ที่ไม่ว่าจะเป็นคุณแม่บ้าน คุณพ่อบ้าน หรือคุณหนูๆ จะมือโปรและมือสมัครเล่น ก็สามารถสร้างสรรค์เมนูเลิศรสอันหลากหลายได้ แล้วยังมีพื้นที่เปิดท้ายขายของ เตรียมไว้ให้เพื่อนๆ ได้เข้ามาซื้อหาแลกเปลี่ยนสินค้าเครื่องครัว ข้าวของเครื่องใช้ต่างๆ ในบ้านกันได้ในราคากันเองอีกด้วย
                                    </p>
                                    <p>
                                            <span class="space-bar"></span>ขอให้เพื่อนๆ คิดว่าเวปไซต์แห่งนี้เป็นพื้นที่ของเราทุกคน แม้เราแต่ละคนอาจจะไม่รู้ทุกเรื่อง แต่เราก็รู้เรื่องบางเรื่องดี (มากทีเดียว) ขอเชิญแวะเข้ามาแลกเปลี่ยนความรู้กันได้ที่เวปแห่งนี้ค่ะ
            
                                    </p>
                                    <p>
                                            <span class="space-bar"></span>สุดท้าย (แต่ไม่ท้ายสุด) ขอบอกว่า เพื่อนๆ มั่นใจได้เลยค่ะ ว่าทุกความลับของการปรุงแต่งอาหารจะถูกเปิดเผยที่นี่แล้ววันนี้โดย UseeUdo.com!
                                    </p>
								</td>
							</tr>
                       </table>
                    </div><!--content-right-->
            </div><!--content-->
            <div class="cleaner"></div>
          
    </div><!--wrapper-->
    <div class="cleaner"></div>
    <div id="wrapper-footer">
    	<div class="adsvertising">
                <?
						include "include/footer.inc.php";
			   ?>
      	</div><!--adsvertising-->  
                      
     <!-- <div id="footer">
      	<p>&nbsp;</p>
      			<table width="980">
                	<tr>
                    	<td align="left">
                        Copyright &copy; 2013 UseeUdo.com<br>
                        43 ชั้น 3 ซอยสุขุมวิท 71 <br>
                        แขวงคลองตันเหนือ เขตวัฒนา กรุงเทพฯ 10110

                        </td>
                        <td align="right">
                         โทร. 02-662-7070  โทรสาร 02-662-7878<br>
                         E-mail : info@useeudo.com <br>
                         Powered by <a href="http://www.baanwebsite.com" target="_blank">baanwebsite.com</a>

                        </td>
                    </tr>
                </table>
         </div>-->
         
    </div><!--wrapper-footer-->        
</body>
</html>
