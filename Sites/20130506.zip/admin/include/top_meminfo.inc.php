<?
	@session_start();
	include_once("wb_config.php");
?>


	ยินดีต้อนรับเข้าสู่ ระบบบริหารจัดการเว็บไซต์<br><br />
	ชื่อเว็บไซต์ : <strong><?=$mywebsite_name?></strong>



