<?php
	echo"<div class='copyright'>Copyright &copy; 2011
	 <a href='http://www.baanwebsite.com'> บ้านเว็บไซต์</a> </div>"


?>
