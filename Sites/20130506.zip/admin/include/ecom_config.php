<?php
	$website_name 	= "www.hi-so-shop.com";
	$website_url 	= "http://www.hi-so-shop.com";
	$admin_email 		= "info@hi-so-shop.com ";  //อีเมล์ผู้รับ
	$noreply_email 		= "no-reply@hi-so-shop.com"; 

	////////////////////////////////////////
	//                     ธีม                    //
	////////////////////////////////////////
	//สี background
	$acolor='ff9600';
	$bcolor='';
	//สีตัวเลขหน้า
	$npagecolor='000000';

?>
