<?php
	$title_name = "ระบบหลังร้าน www.useeudo.com";
	$mywebsite_name = "www.useeudo.com";
	$userlogin_name = "admin";
	$passlogin_name = "useeudo2013";


	////////////////////////////////////////
	//                     ธีม                    //
	////////////////////////////////////////
	//สี background
	$acolor='ff9600';
	$bcolor='';
	//สีตัวเลขหน้า
	$npagecolor='000000';


?>
